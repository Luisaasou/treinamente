package com.treinamente.config;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.*;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;
import java.util.Arrays;

@Configuration
@EnableMethodSecurity
// Centraliza as barreiras de entrada; permissoes finas de perfil continuam perto de cada rota.
public class SecurityConfig {
    @Bean
    // O custo 12 deixa o hash mais caro para ataques sem tornar o login impraticavel no MVP.
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(12); }

    @Bean
    SecurityFilterChain security(HttpSecurity http, AutenticacaoFilter autenticacaoFilter) throws Exception {
        // Como a API usa Bearer e nao cookie de sessao, CSRF nao oferece protecao adicional aqui.
        return http.csrf(csrf -> csrf.disable())
                .cors(cors -> {})
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .exceptionHandling(errors -> errors.authenticationEntryPoint((req, res, ex) -> {
                    res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    res.setContentType("application/json;charset=UTF-8");
                    res.getWriter().write("{\"mensagem\":\"Autenticacao obrigatoria.\"}");
                }))
                .authorizeHttpRequests(auth -> auth
                        // A pagina e seus arquivos precisam carregar antes de existir uma sessao.
                        .requestMatchers("/", "/index.html", "/app.js", "/styles.css",
                                "/manifest.webmanifest", "/robots.txt", "/favicon.ico").permitAll()
                        .requestMatchers("/api/auth/**", "/api/cadastro", "/error").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/publico/**").permitAll()
                        .anyRequest().authenticated())
                .addFilterBefore(autenticacaoFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    CorsConfigurationSource cors(@Value("${app.cors.allowed-origins}") String origens) {
        CorsConfiguration config = new CorsConfiguration();
        // A lista vem do ambiente para evitar liberar qualquer origem por engano em producao.
        config.setAllowedOrigins(Arrays.stream(origens.split(",")).map(String::trim).filter(s -> !s.isBlank()).toList());
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type"));
        config.setAllowCredentials(false);
        config.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
