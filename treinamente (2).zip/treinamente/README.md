# TreinaMente

![versao](https://img.shields.io/badge/vers%C3%A3o-1.0.0--beta-orange)

Plataforma web para estudantes e professores de Educação Física. O professor cria aulas, matricula alunos e atualiza o conteúdo; os alunos acompanham tudo e conversam com a turma no contexto de cada aula. O sistema também tem um painel com números resumidos, um tutor com IA (Gemini) e pesquisa pelo Google.

**Versão atual:** `1.0.0-beta`

## Versionamento

Usei o **Versionamento Semântico (SemVer)**, que escreve a versão no formato:

```text
MAIOR.MENOR.CORREÇÃO-etiqueta
```

Exemplo: `1.0.0-beta`

| Parte | Quando eu aumento | Exemplo |
|---|---|---|
| **MAIOR** | Uma mudança que quebra o que já funcionava (ex.: trocar a estrutura do banco ou mudar as rotas da API) | `1.0.0` → `2.0.0` |
| **MENOR** | Uma funcionalidade nova que não quebra nada do que existe (ex.: um relatório novo no painel) | `1.0.0` → `1.1.0` |
| **CORREÇÃO** | Só conserto de bug, sem funcionalidade nova | `1.0.0` → `1.0.1` |
| **etiqueta** | Indica o estágio: `alpha` (ainda em construção), `beta` (funciona, mas em testes), `rc` (candidata a final). Sem etiqueta, é a versão estável | `1.0.0-beta` → `1.0.0` |

Ao subir de MAIOR, zero MENOR e CORREÇÃO. Ao subir de MENOR, zero a CORREÇÃO.

**Por que `1.0.0-beta`?** O projeto começou como `0.0.1-SNAPSHOT` (o padrão do Maven). Todas as funcionalidades planejadas já funcionam e têm teste de integração (`FluxoAcademicoIntegrationTest`), por isso passei para `1.0.0`. Mantive o `-beta` porque ainda falta validar as integrações externas (Gemini, Google e e-mail) num ambiente de produção de verdade.

A versão fica registrada em três lugares: neste README, no `<version>` do `backend/pom.xml` e nas tags do Git (`git tag v1.0.0-beta`).

### Histórico de versões

| Versão | O que mudou |
|---|---|
| `0.0.1-SNAPSHOT` | Primeiro MVP: cadastro e login |
| `1.0.0-beta` | Plataforma acadêmica completa: instituições, aulas, matrícula, conteúdo, chat da turma, painel, tutor Gemini, pesquisa Google, confirmação de e-mail e recuperação de senha |

## Dashboard

O painel aparece para professores e administradores logo depois do login, na área de trabalho. Ele mostra três números, calculados no backend (`DashboardService`):

- **Aulas**: quantas aulas o professor criou (para o admin, todas da plataforma)
- **Estudantes**: alunos distintos matriculados nas aulas dele
- **Mensagens**: mensagens trocadas nas aulas dele

![Tela do dashboard](docs/dashboard.png)

## Tecnologias

- Backend: Java 17+, Spring Boot, Spring Security, Spring Data JPA, H2 local e MySQL em producao
- Frontend: HTML semantico, CSS responsivo e JavaScript
- Seguranca: BCrypt, sessoes opacas armazenadas como hash, autorizacao por perfil e instituicao

## Funcionalidades

- Cadastro e login de estudantes e professores
- Criacao opcional do primeiro administrador por variaveis de ambiente
- Confirmacao de e-mail e recuperacao de senha por SMTP
- Vinculo de usuarios a uma instituicao
- Criacao de aulas pelo professor
- Matricula de alunos da mesma instituicao
- Publicacao e atualizacao do conteudo da aula
- Acompanhamento do conteudo pelo aluno com atualizacao periodica
- Conversa entre professor e estudantes no contexto da aula
- Painel resumido para professor e administrador
- Tutor Gemini com limites para temas de dor, lesao e diagnostico
- Pesquisa Google Custom Search com SafeSearch
- Base de SEO: metadados, dados estruturados, robots, gerador de sitemap e HTML acessivel

## 1 Banco de dados

No uso local, o sistema cria automaticamente um banco H2 persistente em `backend/data`; nao e preciso instalar MySQL.

Para producao com MySQL 8, execute [database/script.sql](database/script.sql) e configure `DB_URL`, `DB_USERNAME` e `DB_PASSWORD`.

Se o banco veio da primeira versao do MVP, execute uma unica vez:

1. `database/migrations/V2__plataforma_academica.sql`
2. `database/script.sql`

Em desenvolvimento, o Hibernate usa `ddl-auto=update`, mas o script continua sendo a referencia para ambientes controlados.

## 2 Configuracao

Copie as chaves de [.env.example](.env.example) para variaveis de ambiente do sistema ou da configuracao de execucao da IDE. Nao grave valores reais no repositorio.

Configuracao apenas para MySQL:

```text
DB_USERNAME=root
DB_PASSWORD=sua-senha
APP_CORS_ALLOWED_ORIGINS=http://localhost:5500
```

As integracoes Gemini, Google Search e SMTP sao opcionais. Quando uma delas nao esta configurada, o backend responde `503` com uma mensagem explicita em vez de fabricar resultados.

Para criar o primeiro administrador, defina `ADMIN_EMAIL` e `ADMIN_PASSWORD` antes da primeira inicializacao. A senha precisa ter pelo menos 12 caracteres e nunca e registrada nos logs.

## 3 Executar o sistema

No IntelliJ IDEA, abra a pasta `backend` como projeto Maven e execute `TreinaMenteApplication`.

Pelo terminal, use o Maven instalado no ambiente:

```powershell
cd backend
mvn spring-boot:run
```

Backend e frontend iniciam juntos em `http://localhost:8080`. Abra esse endereco no navegador; nao abra `frontend/index.html` diretamente.

## 4 Preparar SEO para deploy

Como o dominio publico ainda nao esta definido no projeto, o sitemap nao deve conter um endereco inventado. No deploy, gere os arquivos com os enderecos reais:

```powershell
.\scripts\configure-seo.ps1 -SiteUrl "https://seu-dominio.com.br" -ApiUrl "https://api.seu-dominio.com.br"
```

O comando atualiza a origem da API e cria `frontend/sitemap.xml` e `frontend/robots.txt` com URLs absolutas. Depois valide o sitemap e cadastre a propriedade nos mecanismos de busca.

## Endpoints principais

| Metodo | Caminho | Perfil |
|---|---|---|
| POST | `/api/auth/registro` | Publico |
| POST | `/api/auth/login` | Publico |
| POST | `/api/auth/verificar-email` | Publico |
| POST | `/api/auth/recuperar-senha` | Publico |
| GET/POST | `/api/aulas` | Autenticado / professor |
| PUT | `/api/aulas/{id}/conteudo` | Professor dono ou admin |
| POST | `/api/aulas/{id}/alunos` | Professor dono ou admin |
| GET/POST | `/api/aulas/{id}/mensagens` | Participante da aula |
| POST | `/api/ia/perguntar` | Autenticado |
| GET | `/api/pesquisas?q=...` | Autenticado |
| GET | `/api/dashboard` | Professor ou admin |

## Privacidade e limites

O sistema nao solicita localizacao nem dados clinicos. Evite inserir informacoes de saude identificaveis no chat ou no tutor. A IA e uma ferramenta de apoio academico e nao substitui avaliacao medica, fisioterapeutica ou de outro profissional habilitado.
